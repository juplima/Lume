import PySimpleGUI as sg
from telas import tela_login, tela_menu, tela_cadastro_produto, tela_listagem_produtos

# ------------------------
# Variáveis globais
# ------------------------
PRODUCTS = []
NEXT_PRODUCT_ID = 1
CART = []
current_screen = "login"

# abre primeira tela
janela = tela_login()

while True:
    evento, valores = janela.read()
    if evento == sg.WIN_CLOSED or evento == "Sair":
        break

    # --- LOGIN ---
    if current_screen == "login":
        if evento == "Entrar":
            if valores["usuario"] == "admin" and valores["senha"] == "123":
                janela.close()
                janela = tela_menu()
                current_screen = "menu"
            else:
                sg.popup("Usuário ou senha incorretos")

    # --- MENU ---
    elif current_screen == "menu":
        if evento == "Cadastrar Produto":
            janela.close()
            janela = tela_cadastro_produto()
            current_screen = "cadastro"
        elif evento == "Listar Produtos":
            janela.close()
            janela = tela_listagem_produtos(PRODUCTS)
            current_screen = "listar"

    # --- CADASTRO DE PRODUTOS ---
    elif current_screen == "cadastro":
        if evento == "Salvar":
            try:
                preco = float(valores["preco"])
                qtd = int(valores["quantidade"])
            except:
                sg.popup("Preço ou quantidade inválidos")
            else:
                PRODUCTS.append({
                    "id": NEXT_PRODUCT_ID,
                    "nome": valores["nome"],
                    "categoria": valores["categoria"],
                    "preco": preco,
                    "quantidade": qtd
                })
                NEXT_PRODUCT_ID += 1
                sg.popup("Produto cadastrado!")
                janela.close()
                janela = tela_menu()
                current_screen = "menu"
        elif evento == "Cancelar":
            janela.close()
            janela = tela_menu()
            current_screen = "menu"

    # --- LISTAGEM DE PRODUTOS ---
    elif current_screen == "listar":
        if evento == "Voltar":
            janela.close()
            janela = tela_menu()
            current_screen = "menu"
        elif evento == "Remover":
            sel = valores.get("-TABLE-")
            if not sel:
                sg.popup("Selecione um produto.")
            else:
                idx = sel[0]
                produto = PRODUCTS.pop(idx)
                sg.popup(f"Produto '{produto['nome']}' removido.")
                janela.close()
                janela = tela_listagem_produtos(PRODUCTS)

 # --- LISTAGEM DE PRODUTOS ---
    elif current_screen == "listar":
        if evento == "Voltar":
            janela.close()
            janela = tela_menu()
            current_screen = "menu"

        elif evento == "Remover":
            sel = valores.get("-TABLE-")
            if not sel:
                sg.popup("Selecione um produto.")
            else:
                idx = sel[0]
                produto = PRODUCTS.pop(idx)
                sg.popup(f"Produto '{produto['nome']}' removido.")
                janela.close()
                janela = tela_listagem_produtos(PRODUCTS)

        elif evento == "Adicionar ao Carrinho":
            sel = valores.get("-TABLE-")
            if not sel:
                sg.popup("Selecione um produto.")
            else:
                idx = sel[0]
                produto = PRODUCTS[idx]
                CART.append(produto)
                sg.popup(f"Produto '{produto['nome']}' adicionado ao carrinho!")
                janela.close()
                janela = tela_carrinho(CART)
                current_screen = "carrinho"

                 # --- CARRINHO ---
    elif current_screen == "carrinho":
        if evento == "Voltar":
            janela.close()
            janela = tela_menu()
            current_screen = "menu"

        elif evento == "Remover do Carrinho":
            sel = valores.get("-CART-")
            if not sel:
                sg.popup("Selecione um item para remover.")
            else:
                idx = sel[0]
                produto = CART.pop(idx)
                sg.popup(f"Produto '{produto['nome']}' removido do carrinho.")
                janela.close()
                janela = tela_carrinho(CART)

        elif evento == "Finalizar Compra":
            if not CART:
                sg.popup("Seu carrinho está vazio!")
            else:
                sg.popup("Compra finalizada com sucesso! Obrigado por comprar conosco 🎮")
                CART.clear()
                janela.close()
                janela = tela_menu()
                current_screen = "menu"
janela.close()

from telas import tela_login, tela_menu, tela_cadastro_produto, tela_listagem_produtos, tela_carrinho
