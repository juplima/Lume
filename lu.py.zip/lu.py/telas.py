import PySimpleGUI as sg

def tela_login():
    layout = [
        [sg.Text("Usuário"), sg.Input(key="usuario")],
        [sg.Text("Senha"), sg.Input(password_char="*", key="senha")],
        [sg.Button("Entrar"), sg.Button("Sair")]
    ]
    return sg.Window("Login", layout, finalize=True)

def tela_menu():
    layout = [
        [sg.Text("Menu Principal")],
        [sg.Button("Cadastrar Produto")],
        [sg.Button("Listar Produtos")],
        [sg.Button("Sair")]
    ]
    return sg.Window("Menu", layout, finalize=True)

def tela_cadastro_produto():
    layout = [
        [sg.Text("Nome:"), sg.Input(key="nome")],
        [sg.Text("Categoria:"), sg.Input(key="categoria")],
        [sg.Text("Preço:"), sg.Input(key="preco")],
        [sg.Text("Quantidade:"), sg.Input(key="quantidade")],
        [sg.Button("Salvar"), sg.Button("Cancelar")]
    ]
    return sg.Window("Cadastro de Produto", layout, finalize=True)

def tela_listagem_produtos(products):
    headings = ["ID", "Nome", "Categoria", "Preço", "Quantidade"]
    data = [[p["id"], p["nome"], p["categoria"], f"R$ {p['preco']:.2f}", p["quantidade"]] for p in products]

    layout = [
        [sg.Text("Listagem de Produtos", font=("Helvetica", 16))],
        [sg.Table(values=data,
                  headings=headings,
                  key="-TABLE-",
                  enable_events=True,
                  select_mode=sg.TABLE_SELECT_MODE_BROWSE,
                  auto_size_columns=False,
                  col_widths=[6, 30, 12, 12, 10],
                  num_rows=10)],
        [sg.Button("Editar"), sg.Button("Remover"), sg.Button("Adicionar ao Carrinho"), sg.Button("Voltar")]
    ]
    return sg.Window("Listagem de Produtos", layout, size=(750, 400), finalize=True)

def tela_carrinho(carrinho):
    headings = ["ID", "Nome", "Categoria", "Preço", "Quantidade"]
    data = [[p["id"], p["nome"], p["categoria"], f"R$ {p['preco']:.2f}", p["quantidade"]] for p in carrinho]

    layout = [
        [sg.Text("Carrinho de Compras", font=("Helvetica", 16))],
        [sg.Table(values=data,
                  headings=headings,
                  key="-CART-",
                  enable_events=True,
                  select_mode=sg.TABLE_SELECT_MODE_BROWSE,
                  auto_size_columns=False,
                  col_widths=[6, 30, 12, 12, 10],
                  num_rows=10)],
        [sg.Button("Remover do Carrinho"), sg.Button("Finalizar Compra"), sg.Button("Voltar")]
    ]
    return sg.Window("Carrinho", layout, size=(750, 400), finalize=True)